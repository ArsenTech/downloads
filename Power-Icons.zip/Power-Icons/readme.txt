///// POWER ICONS /////
- Icon Pack by ArsenTech
- Icons are From Iconfinder
- Remixed by ArsenTech (Except Restart)
- Available on PNG and ICO
- Used for Creating Desktop Shortcuts for Shutdown, Restart, Lock, Sleep, Logout
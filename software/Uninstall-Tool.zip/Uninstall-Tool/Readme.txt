Uninstall Tool 3.5.10

Portable version is pre-activated.

Activation:
1. Install the program using Setup.exe or unpack a portable version from Portable.zip
2. Don't start the program! Check the Tools directory.
3. Copy UninstallToolHelper.exe over to the installation folder, overwrite the current one.
4. Optionally run Cleanup.bat to remove all the previous saved settings and traced installations.
5. Optionally modify the first string in license.dat and copy it over to the installation folder to change the name in About.

Thank you for downloading from the Malware Watch!
https://malwarewatch.org